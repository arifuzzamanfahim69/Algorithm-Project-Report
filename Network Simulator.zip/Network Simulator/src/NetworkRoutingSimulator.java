
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class NetworkRoutingSimulator extends JFrame implements ActionListener {
    private JButton simulateButton;
    private JTextArea displayArea;

    public NetworkRoutingSimulator() {
        // Initialize the window
        setTitle("Network Routing Simulator");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Create the simulate button
        simulateButton = new JButton("Simulate");
        simulateButton.addActionListener(this);

        // Create the display area
        displayArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(displayArea);

        // Add the components to the window
        add(simulateButton, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Show the window
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == simulateButton) {
            // Simulate the network routing
            simulateNetworkRouting();
        }
    }

    private void simulateNetworkRouting() {
        // Create the network topology graph
        int[][] networkTopology = {
                {0, 1, 5, Integer.MAX_VALUE, Integer.MAX_VALUE},
                {1, 0, 3, 7, 5},
                {5, 3, 0, Integer.MAX_VALUE, 1},
                {Integer.MAX_VALUE, 7, Integer.MAX_VALUE, 0, 2},
                {Integer.MAX_VALUE, 5, 1, 2, 0}
        };

        StringBuilder sb = new StringBuilder();

        // Perform Bellman-Ford algorithm
        sb.append("Bellman-Ford Algorithm:\n");
        int[] distancesBF = bellmanFord(networkTopology, 0);
        for (int i = 0; i < distancesBF.length; i++) {
            sb.append("Shortest path from Node 0 to Node ").append(i).append(": ");
            if (distancesBF[i] == Integer.MAX_VALUE) {
                sb.append("No path found");
            } else {
                sb.append(distancesBF[i]);
            }
            sb.append("\n");
        }
        sb.append("\n");

        // Perform Dijkstra's algorithm
        sb.append("Dijkstra's Algorithm:\n");
        int[] distancesDijkstra = dijkstra(networkTopology, 0);
        for (int i = 0; i < distancesDijkstra.length; i++) {
            sb.append("Shortest path from Node 0 to Node ").append(i).append(": ");
            if (distancesDijkstra[i] == Integer.MAX_VALUE) {
                sb.append("No path found");
            } else {
                sb.append(distancesDijkstra[i]);
            }
            sb.append("\n");
        }
        sb.append("\n");

        // Perform Floyd-Warshall algorithm
        sb.append("Floyd-Warshall Algorithm:\n");
        int[][] distancesFW = floydWarshall(networkTopology);
        for (int i = 0; i < distancesFW.length; i++) {
            for (int j = 0; j < distancesFW[i].length; j++) {
                sb.append("Shortest path from Node ").append(i).append(" to Node ").append(j).append(": ");
                if (distancesFW[i][j] == Integer.MAX_VALUE) {
                    sb.append("No path found");
                } else {
                    sb.append(distancesFW[i][j]);
                }
                sb.append("\n");
            }
        }

        // Display the simulation results
        displayArea.setText(sb.toString());
    }

    private int[] bellmanFord(int[][] graph, int source) {
        int V = graph.length;
        int[] distances = new int[V];
        for (int i = 0; i < V; i++) {
            distances[i] = Integer.MAX_VALUE;
        }
        distances[source] = 0;

        for (int i = 1; i < V; i++) {
            for (int j = 0; j < graph.length; j++) {
                for (int k = 0; k < graph.length; k++) {
                    if (graph[j][k] != Integer.MAX_VALUE && distances[j] != Integer.MAX_VALUE
                            && distances[j] + graph[j][k] < distances[k]) {
                        distances[k] = distances[j] + graph[j][k];
                    }
                }
            }
        }

        return distances;
    }

    private int[] dijkstra(int[][] graph, int source) {
        int V = graph.length;
        int[] distances = new int[V];
        boolean[] visited = new boolean[V];
        for (int i = 0; i < V; i++) {
            distances[i] = Integer.MAX_VALUE;
            visited[i] = false;
        }
        distances[source] = 0;

        for (int i = 0; i < V - 1; i++) {
            int minIndex = getMinDistance(distances, visited);
            visited[minIndex] = true;

            for (int j = 0; j < V; j++) {
                if (!visited[j] && graph[minIndex][j] != Integer.MAX_VALUE
                        && distances[minIndex] != Integer.MAX_VALUE
                        && distances[minIndex] + graph[minIndex][j] < distances[j]) {
                    distances[j] = distances[minIndex] + graph[minIndex][j];
                }
            }
        }

        return distances;
    }

    private int getMinDistance(int[] distances, boolean[] visited) {
        int min = Integer.MAX_VALUE;
        int minIndex = -1;

        for (int i = 0; i < distances.length; i++) {
            if (!visited[i] && distances[i] < min) {
                min = distances[i];
                minIndex = i;
            }
        }

        return minIndex;
    }

    private int[][] floydWarshall(int[][] graph) {
        int V = graph.length;
        int[][] distances = new int[V][V];

        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                distances[i][j] = graph[i][j];
            }
        }

        for (int k = 0; k < V; k++) {
            for (int i = 0; i < V; i++) {
                for (int j = 0; j < V; j++) {
                    if (distances[i][k] != Integer.MAX_VALUE && distances[k][j] != Integer.MAX_VALUE
                            && distances[i][k] + distances[k][j] < distances[i][j]) {
                        distances[i][j] = distances[i][k] + distances[k][j];
                    }
                }
            }
        }

        return distances;
    }

    public static void main(String[] args) {
        NetworkRoutingSimulator simulator = new NetworkRoutingSimulator();
    }
}
